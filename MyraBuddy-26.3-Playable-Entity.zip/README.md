# MyraBuddy 26.3 — Playable Entity Build

This build adds the first actual in-world Myra entity.

## Confirmed target
- Minecraft 26.3
- Fabric Loader 0.19.5
- Fabric API 0.161.0+26.3
- Java 25

## Current playable feature
Run:

    /myra spawn

Myra spawns beside you, gets a visible name, and follows the nearest/player target using Minecraft navigation.

## Current limitation
The first build uses a temporary vanilla humanoid-style renderer so the entity can be visible without requiring a custom skin/model asset. The next build should replace this with a dedicated Myra player-style model/texture.

AI chat, mining, building, combat, memory and Android controls remain separate modules and are not falsely marked as complete.

## Mojo
After the project is compiled into a JAR, the JAR belongs in the same Fabric instance's `mods` folder. The instance must use Minecraft 26.3 and a compatible Fabric Loader.
