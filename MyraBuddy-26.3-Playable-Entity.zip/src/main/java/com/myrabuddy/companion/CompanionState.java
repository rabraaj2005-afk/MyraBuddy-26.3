package com.myrabuddy.companion;

public enum CompanionState {
    IDLE,
    FOLLOWING,
    MOVING,
    GATHERING,
    MINING,
    CRAFTING,
    BUILDING,
    COMBAT,
    EXPLORING,
    RETURNING,
    WAITING
}
