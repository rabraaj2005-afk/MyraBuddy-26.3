package com.myrabuddy.companion;

public final class CompanionManager {
    private String state = "IDLE";

    public String status() {
        return "Myra state: " + state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void stop() {
        this.state = "IDLE";
    }
}
