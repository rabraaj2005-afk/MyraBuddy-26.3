package com.myrabuddy.client;

import com.myrabuddy.entity.MyraEntityTypes;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.client.renderer.entity.ZombieRenderer;

public final class MyraBuddyClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Temporary humanoid-style renderer for the first playable build.
        // A dedicated Myra skin/model can replace this renderer later.
        EntityRenderers.register(MyraEntityTypes.MYRA, ZombieRenderer::new);
    }
}
