package com.myrabuddy.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;

public class MyraEntity extends PathfinderMob {
    private Player followTarget;

    public MyraEntity(EntityType<? extends MyraEntity> type, Level level) {
        super(type, level);
        this.setCustomNameVisible(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.30)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    public void setFollowTarget(Player player) {
        this.followTarget = player;
    }

    public Player getFollowTarget() {
        return followTarget;
    }

    @Override
    public void tick() {
        super.tick();

        if (level().isClientSide()) return;
        if (followTarget == null || !followTarget.isAlive()) {
            followTarget = level().getNearestPlayer(this, 32.0);
        }

        if (followTarget != null) {
            double distance = this.distanceTo(followTarget);

            if (distance > 4.0 && distance < 32.0) {
                this.getNavigation().moveTo(
                        followTarget.getX(),
                        followTarget.getY(),
                        followTarget.getZ(),
                        1.15
                );
            } else if (distance <= 3.0) {
                this.getNavigation().stop();
            }
        }
    }
}
