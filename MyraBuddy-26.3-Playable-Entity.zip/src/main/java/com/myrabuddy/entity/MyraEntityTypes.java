package com.myrabuddy.entity;

import com.myrabuddy.MyraBuddy;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MobCategory;

public final class MyraEntityTypes {
    public static final ResourceKey<EntityType<?>> MYRA_KEY =
            ResourceKey.create(Registries.ENTITY_TYPE, MyraBuddy.id("myra"));

    public static final EntityType<MyraEntity> MYRA = register(
            MYRA_KEY,
            EntityType.Builder.of(MyraEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.8f)
                    .clientTrackingRange(10)
    );

    private static <T extends Entity> EntityType<T> register(
            ResourceKey<EntityType<?>> key,
            EntityType.Builder<T> builder
    ) {
        return BuiltInRegistries.ENTITY_TYPE.register(key, builder.build(key));
    }

    public static void initialize() {
        FabricDefaultAttributeRegistry.register(MYRA, MyraEntity.createAttributes());
    }

    private MyraEntityTypes() {}
}
