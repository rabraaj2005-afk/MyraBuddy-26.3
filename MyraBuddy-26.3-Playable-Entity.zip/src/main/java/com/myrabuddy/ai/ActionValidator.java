package com.myrabuddy.ai;

import java.util.Set;

public final class ActionValidator {
    private static final Set<String> ALLOWED = Set.of(
        "FOLLOW_PLAYER",
        "MOVE_TO",
        "STOP",
        "GATHER",
        "MINE",
        "CRAFT",
        "BUILD",
        "ATTACK",
        "DEFEND",
        "EXPLORE",
        "RETURN_TO_PLAYER",
        "WAIT"
    );

    private ActionValidator() {}

    public static boolean isAllowed(AIResponse.AIAction action) {
        return action != null
            && action.type() != null
            && ALLOWED.contains(action.type())
            && action.amount() >= 0
            && action.amount() <= 256;
    }
}
