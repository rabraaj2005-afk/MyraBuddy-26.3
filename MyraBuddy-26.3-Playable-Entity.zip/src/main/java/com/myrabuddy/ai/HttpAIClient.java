package com.myrabuddy.ai;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Provider-neutral starting point.
 * The actual provider request/JSON parsing should be added behind this class.
 * API keys must never be hard-coded.
 */
public final class HttpAIClient implements AIClient {
    private final HttpClient client = HttpClient.newHttpClient();

    @Override
    public CompletableFuture<AIResponse> chat(String playerMessage) {
        String endpoint = System.getenv("MYRABUDDY_AI_ENDPOINT");

        if (endpoint == null || endpoint.isBlank()) {
            return CompletableFuture.completedFuture(
                new AIResponse(
                    "My AI connection isn't configured yet. Set MYRABUDDY_AI_ENDPOINT.",
                    List.of()
                )
            );
        }

        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(endpoint))
            .header("Content-Type", "application/json")
            .POST(HttpRequest.BodyPublishers.ofString(
                "{"message":"" + escape(playerMessage) + ""}"
            ))
            .build();

        return client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
            .thenApply(response -> new AIResponse(
                "AI response received. Provider JSON parsing is the next implementation step.",
                List.of()
            ));
    }

    private static String escape(String input) {
        return input.replace("\\", "\\\\").replace(""", "\\"");
    }
}
