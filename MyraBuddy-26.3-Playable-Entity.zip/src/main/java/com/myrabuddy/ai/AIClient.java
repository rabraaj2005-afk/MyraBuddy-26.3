package com.myrabuddy.ai;

import java.util.concurrent.CompletableFuture;

public interface AIClient {
    CompletableFuture<AIResponse> chat(String playerMessage);
}
