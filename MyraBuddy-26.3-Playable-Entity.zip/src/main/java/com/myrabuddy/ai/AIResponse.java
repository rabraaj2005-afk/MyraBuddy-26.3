package com.myrabuddy.ai;

import java.util.List;

public record AIResponse(
    String message,
    List<AIAction> actions
) {
    public record AIAction(String type, String target, int amount) {}
}
