package com.myrabuddy;

import com.myrabuddy.ai.AIClient;
import com.myrabuddy.ai.HttpAIClient;
import com.myrabuddy.companion.CompanionManager;
import com.myrabuddy.entity.MyraEntity;
import com.myrabuddy.entity.MyraEntityTypes;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public class MyraBuddy implements ModInitializer {
    public static final String MOD_ID = "myrabuddy";
    public static CompanionManager COMPANION;
    public static AIClient AI;

    public static net.minecraft.resources.ResourceLocation id(String path) {
        return net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        COMPANION = new CompanionManager();
        AI = new HttpAIClient();

        MyraEntityTypes.initialize();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(Commands.literal("myra")
                .then(Commands.literal("spawn")
                    .executes(ctx -> {
                        ServerPlayer player = ctx.getSource().getPlayerOrException();

                        MyraEntity myra = MyraEntityTypes.MYRA.create(player.level(), net.minecraft.world.entity.EntitySpawnReason.COMMAND);
                        if (myra == null) {
                            ctx.getSource().sendFailure(Component.literal("Could not create Myra."));
                            return 0;
                        }

                        myra.moveTo(
                                player.getX() + 1.5,
                                player.getY(),
                                player.getZ() + 1.5,
                                player.getYRot(),
                                0
                        );
                        myra.setCustomName(Component.literal("Myra"));
                        myra.setFollowTarget(player);
                        player.level().addFreshEntity(myra);

                        ctx.getSource().sendSuccess(
                                () -> Component.literal("Myra: I'm here! 👋"),
                                false
                        );
                        return 1;
                    }))
                .then(Commands.literal("status")
                    .executes(ctx -> {
                        ctx.getSource().sendSuccess(
                                () -> Component.literal(COMPANION.status()),
                                false
                        );
                        return 1;
                    }))
                .then(Commands.literal("stop")
                    .executes(ctx -> {
                        COMPANION.stop();
                        ctx.getSource().sendSuccess(
                                () -> Component.literal("Myra: Okay, I'll stay here."),
                                false
                        );
                        return 1;
                    }))
            );
        });
    }
}
